/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataAzurestackKeyVaultAccessPolicyAConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy#id DataAzurestackKeyVaultAccessPolicyA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy#name DataAzurestackKeyVaultAccessPolicyA#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy#timeouts DataAzurestackKeyVaultAccessPolicyA#timeouts}
    */
    readonly timeouts?: DataAzurestackKeyVaultAccessPolicyTimeouts;
}
export interface DataAzurestackKeyVaultAccessPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy#read DataAzurestackKeyVaultAccessPolicyA#read}
    */
    readonly read?: string;
}
export declare function dataAzurestackKeyVaultAccessPolicyTimeoutsToTerraform(struct?: DataAzurestackKeyVaultAccessPolicyTimeouts | cdktf.IResolvable): any;
export declare function dataAzurestackKeyVaultAccessPolicyTimeoutsToHclTerraform(struct?: DataAzurestackKeyVaultAccessPolicyTimeouts | cdktf.IResolvable): any;
export declare class DataAzurestackKeyVaultAccessPolicyTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurestackKeyVaultAccessPolicyTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataAzurestackKeyVaultAccessPolicyTimeouts | cdktf.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy azurestack_key_vault_access_policy}
*/
export declare class DataAzurestackKeyVaultAccessPolicyA extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "azurestack_key_vault_access_policy";
    /**
    * Generates CDKTF code for importing a DataAzurestackKeyVaultAccessPolicyA resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurestackKeyVaultAccessPolicyA to import
    * @param importFromId The id of the existing DataAzurestackKeyVaultAccessPolicyA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurestackKeyVaultAccessPolicyA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/data-sources/key_vault_access_policy azurestack_key_vault_access_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurestackKeyVaultAccessPolicyAConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurestackKeyVaultAccessPolicyAConfig);
    get certificatePermissions(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyPermissions(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get secretPermissions(): string[];
    private _timeouts;
    get timeouts(): DataAzurestackKeyVaultAccessPolicyTimeoutsOutputReference;
    putTimeouts(value: DataAzurestackKeyVaultAccessPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataAzurestackKeyVaultAccessPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
