/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkSecurityRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#access NetworkSecurityRule#access}
    */
    readonly access: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#description NetworkSecurityRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#destination_address_prefix NetworkSecurityRule#destination_address_prefix}
    */
    readonly destinationAddressPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#destination_address_prefixes NetworkSecurityRule#destination_address_prefixes}
    */
    readonly destinationAddressPrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#destination_port_range NetworkSecurityRule#destination_port_range}
    */
    readonly destinationPortRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#destination_port_ranges NetworkSecurityRule#destination_port_ranges}
    */
    readonly destinationPortRanges?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#direction NetworkSecurityRule#direction}
    */
    readonly direction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#id NetworkSecurityRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#name NetworkSecurityRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#network_security_group_name NetworkSecurityRule#network_security_group_name}
    */
    readonly networkSecurityGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#priority NetworkSecurityRule#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#protocol NetworkSecurityRule#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#resource_group_name NetworkSecurityRule#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#source_address_prefix NetworkSecurityRule#source_address_prefix}
    */
    readonly sourceAddressPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#source_address_prefixes NetworkSecurityRule#source_address_prefixes}
    */
    readonly sourceAddressPrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#source_port_range NetworkSecurityRule#source_port_range}
    */
    readonly sourcePortRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#source_port_ranges NetworkSecurityRule#source_port_ranges}
    */
    readonly sourcePortRanges?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#timeouts NetworkSecurityRule#timeouts}
    */
    readonly timeouts?: NetworkSecurityRuleTimeouts;
}
export interface NetworkSecurityRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#create NetworkSecurityRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#delete NetworkSecurityRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#read NetworkSecurityRule#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#update NetworkSecurityRule#update}
    */
    readonly update?: string;
}
export declare function networkSecurityRuleTimeoutsToTerraform(struct?: NetworkSecurityRuleTimeouts | cdktf.IResolvable): any;
export declare function networkSecurityRuleTimeoutsToHclTerraform(struct?: NetworkSecurityRuleTimeouts | cdktf.IResolvable): any;
export declare class NetworkSecurityRuleTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkSecurityRuleTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkSecurityRuleTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule azurestack_network_security_rule}
*/
export declare class NetworkSecurityRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "azurestack_network_security_rule";
    /**
    * Generates CDKTF code for importing a NetworkSecurityRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkSecurityRule to import
    * @param importFromId The id of the existing NetworkSecurityRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkSecurityRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurestack/1.0.0/docs/resources/network_security_rule azurestack_network_security_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkSecurityRuleConfig
    */
    constructor(scope: Construct, id: string, config: NetworkSecurityRuleConfig);
    private _access?;
    get access(): string;
    set access(value: string);
    get accessInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationAddressPrefix?;
    get destinationAddressPrefix(): string;
    set destinationAddressPrefix(value: string);
    resetDestinationAddressPrefix(): void;
    get destinationAddressPrefixInput(): string | undefined;
    private _destinationAddressPrefixes?;
    get destinationAddressPrefixes(): string[];
    set destinationAddressPrefixes(value: string[]);
    resetDestinationAddressPrefixes(): void;
    get destinationAddressPrefixesInput(): string[] | undefined;
    private _destinationPortRange?;
    get destinationPortRange(): string;
    set destinationPortRange(value: string);
    resetDestinationPortRange(): void;
    get destinationPortRangeInput(): string | undefined;
    private _destinationPortRanges?;
    get destinationPortRanges(): string[];
    set destinationPortRanges(value: string[]);
    resetDestinationPortRanges(): void;
    get destinationPortRangesInput(): string[] | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkSecurityGroupName?;
    get networkSecurityGroupName(): string;
    set networkSecurityGroupName(value: string);
    get networkSecurityGroupNameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _sourceAddressPrefix?;
    get sourceAddressPrefix(): string;
    set sourceAddressPrefix(value: string);
    resetSourceAddressPrefix(): void;
    get sourceAddressPrefixInput(): string | undefined;
    private _sourceAddressPrefixes?;
    get sourceAddressPrefixes(): string[];
    set sourceAddressPrefixes(value: string[]);
    resetSourceAddressPrefixes(): void;
    get sourceAddressPrefixesInput(): string[] | undefined;
    private _sourcePortRange?;
    get sourcePortRange(): string;
    set sourcePortRange(value: string);
    resetSourcePortRange(): void;
    get sourcePortRangeInput(): string | undefined;
    private _sourcePortRanges?;
    get sourcePortRanges(): string[];
    set sourcePortRanges(value: string[]);
    resetSourcePortRanges(): void;
    get sourcePortRangesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): NetworkSecurityRuleTimeoutsOutputReference;
    putTimeouts(value: NetworkSecurityRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NetworkSecurityRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
